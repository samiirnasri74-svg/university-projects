namespace lab_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = $"Greeting App - started {DateTime.Now}";
        }

        private void btnGreet_Click(object sender, EventArgs e)
        {
            lblOutput.Text = $"Hello, {txtName.Text}!";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            lblOutput.Text = "";
            txtName.Focus();
        }
    }
}

