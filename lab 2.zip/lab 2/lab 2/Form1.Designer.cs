﻿namespace lab_2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblPrompt;
        private TextBox txtName;
        private Button btnGreet;
        private Label lblOutput;
        private Button btnClear;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(420, 200);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Greeting App";

            lblPrompt = new Label();
            lblPrompt.Name = "lblPrompt";
            lblPrompt.Text = "Enter your name:";
            lblPrompt.Location = new Point(20, 25);
            lblPrompt.AutoSize = true;
            lblPrompt.TabIndex = 0;

            txtName = new TextBox();
            txtName.Name = "txtName";
            txtName.Width = 300;
            txtName.Location = new Point(150, 22);
            txtName.TabIndex = 0;

            btnGreet = new Button();
            btnGreet.Name = "btnGreet";
            btnGreet.Text = "Greet Me";
            btnGreet.Location = new Point(150, 60);
            btnGreet.Width = 120;
            btnGreet.TabIndex = 1;
            btnGreet.Click += new EventHandler(btnGreet_Click);

            lblOutput = new Label();
            lblOutput.Name = "lblOutput";
            lblOutput.Text = "(leave empty)";
            lblOutput.AutoSize = true;
            lblOutput.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            lblOutput.ForeColor = Color.DarkBlue;
            lblOutput.Location = new Point(20, 110);
            lblOutput.TabIndex = 2;

            btnClear = new Button();
            btnClear.Name = "btnClear";
            btnClear.Text = "Clear";
            btnClear.Location = new Point(280, 60);
            btnClear.Width = 120;
            btnClear.TabIndex = 2;
            btnClear.Click += new EventHandler(btnClear_Click);

            this.AcceptButton = btnGreet;
            this.Controls.Add(lblPrompt);
            this.Controls.Add(txtName);
            this.Controls.Add(btnGreet);
            this.Controls.Add(lblOutput);
            this.Controls.Add(btnClear);
        }

        #endregion
    }
}
