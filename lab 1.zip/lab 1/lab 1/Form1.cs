using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab01FirstForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.Text = "My First Application";
            this.BackColor = Color.FromArgb(230, 240, 255);
            this.Size = new Size(800, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
        }
    }
}
