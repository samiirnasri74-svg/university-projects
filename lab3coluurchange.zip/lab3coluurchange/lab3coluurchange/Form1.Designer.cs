﻿using System.Drawing;
using System.Windows.Forms;

namespace lab3coluurchange
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCount = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRed = new System.Windows.Forms.Button();
            this.btnGreen = new System.Windows.Forms.Button();
            this.btnBlue = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            this.lblCount.Location = new Point(24, 20);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new Size(36, 45);
            this.lblCount.TabIndex = 0;
            this.lblCount.Text = "0";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new Point(24, 90);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(120, 40);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Click Me";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += btnAdd_Click;
            // 
            // btnRed
            // 
            this.btnRed.Location = new Point(24, 150);
            this.btnRed.Name = "btnRed";
            this.btnRed.Size = new Size(75, 30);
            this.btnRed.TabIndex = 2;
            this.btnRed.Text = "Red";
            this.btnRed.UseVisualStyleBackColor = true;
            this.btnRed.Click += ColourButton_Click;
            // 
            // btnGreen
            // 
            this.btnGreen.Location = new Point(110, 150);
            this.btnGreen.Name = "btnGreen";
            this.btnGreen.Size = new Size(75, 30);
            this.btnGreen.TabIndex = 3;
            this.btnGreen.Text = "Green";
            this.btnGreen.UseVisualStyleBackColor = true;
            this.btnGreen.Click += ColourButton_Click;
            // 
            // btnBlue
            // 
            this.btnBlue.Location = new Point(196, 150);
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Size = new Size(75, 30);
            this.btnBlue.TabIndex = 4;
            this.btnBlue.Text = "Blue";
            this.btnBlue.UseVisualStyleBackColor = true;
            this.btnBlue.Click += ColourButton_Click;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new Point(24, 210);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new Size(0, 15);
            this.lblStatus.TabIndex = 5;
            this.lblStatus.Text = string.Empty;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(this.lblStatus);
            Controls.Add(this.btnBlue);
            Controls.Add(this.btnGreen);
            Controls.Add(this.btnRed);
            Controls.Add(this.btnAdd);
            Controls.Add(this.lblCount);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            this.FormClosing += Form1_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRed;
        private System.Windows.Forms.Button btnGreen;
        private System.Windows.Forms.Button btnBlue;
        private System.Windows.Forms.Label lblStatus;

        #endregion
    }
}
