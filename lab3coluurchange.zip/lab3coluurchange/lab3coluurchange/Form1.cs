using System;
using System.Drawing;
using System.Windows.Forms;

namespace lab3coluurchange
{
    public partial class Form1 : Form
    {
        // Part A: Click counter field
        private int clickCount = 0;

        public Form1()
        {
            InitializeComponent();
            // Note: event wiring can be done in the Designer or here. If your Designer
            // is not wired, you can uncomment the lines below to attach handlers at runtime.
            // btnAdd.Click += btnAdd_Click;
            // btnRed.Click += ColourButton_Click;
            // btnGreen.Click += ColourButton_Click;
            // btnBlue.Click += ColourButton_Click;
            // this.Load += Form1_Load;
            // this.FormClosing += Form1_FormClosing;
        }

        #region Part D - Form Events
        // Form Load event: initialize UI state
        private void Form1_Load(object sender, EventArgs e)
        {
            lblStatus.Text = "Ready - click a colour to start";
            lblCount.Text = "0";
        }

        // Form Closing event: confirm before exit
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to exit?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
        #endregion

        #region Part A - Click Counter
        // Handler for btnAdd (Click Me) - increments clickCount and updates lblCount
        private void btnAdd_Click(object sender, EventArgs e)
        {
            clickCount++;
            lblCount.Text = clickCount.ToString();
        }
        #endregion

        #region Part B - Colour Buttons (shared handler)
        // Shared handler for btnRed, btnGreen, btnBlue
        private void ColourButton_Click(object sender, EventArgs e)
        {
            // Safe cast using pattern matching
            if (sender is Button clicked)
            {
                string text = clicked.Text ?? string.Empty;
                lblStatus.Text = $"You clicked: {text}";

                // Decide colour based on button text
                if (text.Equals("Red", StringComparison.OrdinalIgnoreCase))
                {
                    this.BackColor = Color.LightCoral;
                }
                else if (text.Equals("Green", StringComparison.OrdinalIgnoreCase))
                {
                    this.BackColor = Color.LightGreen;
                }
                else if (text.Equals("Blue", StringComparison.OrdinalIgnoreCase))
                {
                    this.BackColor = Color.LightSkyBlue;
                }
            }
        }
        #endregion
    }
}
