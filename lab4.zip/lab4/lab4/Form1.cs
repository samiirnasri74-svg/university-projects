using System;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Part B: fill ComboBox
            cmbCourse.Items.Add("C# Programming");
            cmbCourse.Items.Add("Databases");
            cmbCourse.Items.Add("Mathematics");
            cmbCourse.Items.Add("Web Development");
            if (cmbCourse.Items.Count > 0)
                cmbCourse.SelectedIndex = 0;

            // Date restrictions
            dtpBirth.MaxDate = DateTime.Today;
            dtpBirth.MinDate = DateTime.Today.AddYears(-100);
            dtpBirth.Value = new DateTime(2004, 1, 1);
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // Part C - read every control
            string name = txtFullName.Text?.Trim() ?? string.Empty;

            string gender = string.Empty;
            if (rdoMale.Checked) gender = "Male";
            else if (rdoFemale.Checked) gender = "Female";
            else gender = "Unspecified";

            var birth = dtpBirth.Value;
            int age = DateTime.Today.Year - birth.Year;
            if (birth > DateTime.Today.AddYears(-age)) age--;

            string course = cmbCourse.SelectedItem != null ? cmbCourse.SelectedItem.ToString() : string.Empty;
            int groupSize = (int)nudGroup.Value;
            bool newsletter = chkNewsletter.Checked;

            string entry = $"{name} - {gender}, Age: {age}, Course: {course}, Group size: {groupSize}, Newsletter: {(newsletter ? "Yes" : "No")}";
            lstRegistered.Items.Add(entry);
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            // Part E - safety guard and removal
            if (lstRegistered.SelectedIndex == -1)
            {
                MessageBox.Show("Select a student first.", "Nothing selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            lstRegistered.Items.RemoveAt(lstRegistered.SelectedIndex);
        }
    }
}
